package com.tvacstudio.a_commerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
